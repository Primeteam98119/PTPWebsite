jQuery(document).ready(function() {
    var generateFormToken = function() {
        return "ft" + Math.random().toString(36).slice(2);
    };
    var init = function() {
        var registerEmail = function(email, source) {
            var token = generateFormToken();
            var formHost = $("<div/>").attr("id", "formhost" + token).appendTo("body").hide();
            var formTarget = $("<iframe/>").attr("name", "target" + token).appendTo("body").hide();
            var specialForms = {
                "Drift": "afe4a930-9593-4d5d-9124-029b204dbd5f",
                "Calendly": "2b2cefbe-4526-4687-a4f4-01d6ec02a461"
            };
            hbspt.forms.create({ 
                css: '',
                portalId: '346178',
                formId: specialForms[source] || '5dc96bd8-7d4b-4eeb-9042-d81b52cc31a5',
                target: "#" + formHost.attr("id"),
                redirectUrl: "http://w.inboundlabs.co/d9e13ab6-e92e-4fc3-8714-1e39065b4f7a",
                formInstanceId: token,
                onFormReady: function($form) {
                    if ($form.find("[name=email]").val()) {
                        // Already identified
                        console.log($form.find("[name=email]").val());
                        return;
                    }
                    setTimeout(function() {
                        $form.attr("target", formTarget.attr("name"));
                        $form.find("[name=email]").val(email).change();
                        $form.find("[name=email_source]").val(source).change();
                        $form.find("[name=source]").val(source).change();
                        $form.submit();
                    }, 100);
                }
            });
        };
        if (window.drift) {
            drift.on('emailCapture', function(e) {
                registerEmail(e.data.email, "Drift");
            });
        }
        if (window.__ilRegisterEmail && window.__ilRegisterEmail.email) {
            registerEmail(window.__ilRegisterEmail.email, window.__ilRegisterEmail.source);
        }
    };
    var pendingComps = 1;
    var onCompLoad = function() {
        pendingComps--;
        if (pendingComps <= 0) {
            init();
        }
    };
    var loadScript = function(url, callback) {
        // Adding the script tag to the head as suggested before
        var ref = document.getElementsByTagName('script')[0];
        var script = document.createElement('script');
        script.type = 'text/javascript';
        script.src = url;
        script.async = true;

        // Then bind the event to the callback function.
        // There are several events for cross browser compatibility.
        var cbCalled = false;
        var cbHandler = function() {
            if ( !cbCalled && (!this.readyState || this.readyState == 'complete') ) {
                cbCalled = true;
                callback();
            }
        };
        script.onreadystatechange = cbHandler;
        script.onload = cbHandler;

        // Fire the loading
        ref.parentNode.insertBefore(script, ref);
    }
    var loadScriptFor = function(url, cond) {
        if (cond) {
            return;
        }
        pendingComps++;
        loadScript(url, onCompLoad);
    };
    loadScriptFor("//js.hsforms.net/forms/v2.js", window.hbspt && window.hbspt.forms);
    onCompLoad();
});